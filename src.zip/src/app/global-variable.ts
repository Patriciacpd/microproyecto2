export let loggedin:boolean = false;

export let userID:string = "";