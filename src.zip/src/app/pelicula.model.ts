export class Pelicula {
    nombre:string;
    imagen:string;
    url:string = "https://image.tmdb.org/t/p/w780/";
    idiomas:string;
    popularidad:string;
}
