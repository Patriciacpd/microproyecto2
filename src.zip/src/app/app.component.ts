import { AuthService } from './auth.service';
import { Component, TemplateRef } from '@angular/core';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'microproyecto2';

  constructor(
    public authService:AuthService,private modalService: BsModalService
  ) {
  }
  modalRef: BsModalRef;


  openModal(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template);
  }
  ngOnInit() {
    console.log("************************")
  }


  isLoggedIn():boolean{
    return JSON.parse(localStorage.getItem('user'))!==null;
  }

  logout(){
    console.log(JSON.parse(localStorage.getItem('user')))
    this.authService.logout();
    console.log(JSON.parse(localStorage.getItem('user')))
  }
}
