import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lista-reservas',
  templateUrl: './lista-reservas.component.html',
  styleUrls: ['./lista-reservas.component.scss']
})
export class ListaReservasComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
