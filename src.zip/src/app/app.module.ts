import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';

import { AppComponent } from './app.component';
import { InfoPeliculaComponent } from './InfoPelicula/info-pelicula/info-pelicula.component';
import { ListaReservasComponent } from './ListaReservas/lista-reservas/lista-reservas.component';

import { LoginComponent } from './Login/login/login.component';
import { CrearReservaComponent } from './crearReserva/crear-reserva/crear-reserva.component';
import { RegistroComponent } from './Registro/registro/registro.component';

import {ButtonsModule} from 'ngx-bootstrap/buttons';
import {BsModalService, ModalModule} from "ngx-bootstrap/modal";
import { AppRoutingModule } from './app-routing.module';
import {AngularFireAuthModule} from "@angular/fire/auth";
import {AngularFirestoreModule} from "@angular/fire/firestore";
import {AngularFireModule} from "@angular/fire";
import {environment} from "../environments/environment";
import {ComponentLoaderFactory} from "ngx-bootstrap/component-loader";
import {PositioningService} from "ngx-bootstrap/positioning";
import { ListaPeliculasComponent } from './ListaPeliculas/lista-peliculas/lista-peliculas.component';
import { PeliculaComponent } from './Pelicula/pelicula/pelicula.component';
import {BsDropdownConfig, BsDropdownModule} from "ngx-bootstrap/dropdown";

@NgModule({
  declarations: [
    AppComponent,

    LoginComponent,
    CrearReservaComponent,
    RegistroComponent,

    InfoPeliculaComponent,
    ListaReservasComponent,
    ListaPeliculasComponent,
    PeliculaComponent,

  ],
  imports: [
    BrowserModule,
    ButtonsModule,
    ModalModule,
    HttpClientModule,
    AppRoutingModule,
    AngularFireModule.initializeApp(environment.firebase),
    AngularFirestoreModule,
    AngularFireAuthModule,
    BsDropdownModule
  ],
  providers: [
    BsModalService,
    ComponentLoaderFactory,
    PositioningService,
    BsDropdownConfig ],
  bootstrap: [AppComponent]
})
export class AppModule { }
