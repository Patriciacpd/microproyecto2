import { Pelicula } from './pelicula.model';

describe('Pelicula', () => {
  it('should create an instance', () => {
    expect(new Pelicula()).toBeTruthy();
  });
});
