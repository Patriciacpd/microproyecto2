// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebase: {apiKey: "AIzaSyCV3tQTljPmwRmVO5jAs6OnhvFEvFylojU",
    authDomain: "microproyecto2-7d9d2.firebaseapp.com",
    projectId: "microproyecto2-7d9d2",
    storageBucket: "microproyecto2-7d9d2.appspot.com",
    messagingSenderId: "967655134508",
    appId: "1:967655134508:web:8dcea370b05fdfe741c889",
    measurementId: "G-7YQX10T8E0"}
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
